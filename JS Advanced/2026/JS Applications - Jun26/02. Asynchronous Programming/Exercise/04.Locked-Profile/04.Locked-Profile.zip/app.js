async function lockedProfile() {

    const main = document.getElementById('main');
    main.innerHTML = '';

    const response = await fetch('http://localhost:3030/jsonstore/advanced/profiles');
    const data = await response.json();

    let index = 1;

    Object.values(data).forEach(user => {

        const profile = document.createElement('div');
        profile.className = 'profile';

        profile.innerHTML = `
            <img src="./iconProfile2.png" class="userIcon" />
            <label>Lock</label>
            <input type="radio" name="user${index}Locked" value="lock" checked>
            <label>Unlock</label>
            <input type="radio" name="user${index}Locked" value="unlock"><br>
            <hr>
            <label>Username</label>
            <input type="text" name="user${index}Username" value="${user.username}" disabled readonly />
            <div class="hiddenInfo" style="display:none">
                <hr>
                <label>Email:</label>
                <input type="email" name="user${index}Email" value="${user.email}" disabled readonly />
                <label>Age:</label>
                <input type="number" name="user${index}Age" value="${user.age}" disabled readonly />
            </div>
            <button>Show more</button>
        `;

        const button = profile.querySelector('button');

        button.addEventListener('click', () => {

            const unlocked = profile.querySelector('input[value="unlock"]').checked;

            if (!unlocked) {
                return;
            }

            const hiddenInfo = profile.querySelector('.hiddenInfo');

            if (button.textContent === 'Show more') {
                hiddenInfo.style.display = 'block';
                button.textContent = 'Hide it';
            } else {
                hiddenInfo.style.display = 'none';
                button.textContent = 'Show more';
            }
        });

        main.appendChild(profile);
        index++;
    });

}