import page from '../node_modules/page/page.mjs';
import { render } from '../node_modules/lit-html/lit-html.js';

import { homeView } from './views/home.js';
import { loginView } from './views/login.js';
import { registerView } from './views/register.js';

const main = document.getElementById('main-element');

const userNav = document.querySelector('.user');
const guestNav = document.querySelector('.guest');

page(decorateContext);

page('/', homeView);
page('/login', loginView);
page('/register', registerView);

page.start();

function decorateContext(current, next) {
    current.render = (template) => render(template, main);
    current.goTo = page.redirect;

    next();
}